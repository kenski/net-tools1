require(netassess);
newsites();
q(save="no");
