require(netassess);
rembias();
q(save="no");
